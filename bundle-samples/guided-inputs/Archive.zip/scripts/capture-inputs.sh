#!/usr/bin/env sh
set -eu

: "${OZ_OUTPUT:?OZ_OUTPUT env var is required}"

PROJECT_NAME="${1}"
INSTANCE_COUNT="${2}"
ENABLE_BUDGET="${3:-}"
LABELS_JSON="${4:-{}}"
REGIONS_JSON="${5}"

if [ -z "${ENABLE_BUDGET}" ]; then
  ENABLE_BUDGET="false"
fi

printf 'projectName=%s\n' "${PROJECT_NAME}" >> "${OZ_OUTPUT}"
printf 'instanceCount=%s\n' "${INSTANCE_COUNT}" >> "${OZ_OUTPUT}"
printf 'enableBudget=%s\n' "${ENABLE_BUDGET}" >> "${OZ_OUTPUT}"
printf 'labelsJson=%s\n' "${LABELS_JSON}" >> "${OZ_OUTPUT}"
printf 'regionsJson=%s\n' "${REGIONS_JSON}" >> "${OZ_OUTPUT}"
printf 'summary=%s\n' "project=${PROJECT_NAME}; instances=${INSTANCE_COUNT}; budget=${ENABLE_BUDGET}" >> "${OZ_OUTPUT}"

echo "Captured typed inputs for ${PROJECT_NAME}"
echo "labels=${LABELS_JSON}"
echo "regions=${REGIONS_JSON}"
